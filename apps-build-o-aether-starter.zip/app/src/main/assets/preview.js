(() => {
  const frame = document.getElementById('resultFrame');
  const errors = document.getElementById('errors');
  const status = document.getElementById('status');
  let logItems = [];
  function renderErrors() {
    errors.replaceChildren();
    if (!logItems.length) { errors.textContent = 'কোনো ত্রুটি পাওয়া যায়নি।'; return; }
    logItems.forEach(item => {
      const div = document.createElement('div');
      div.className = item.type === 'error' ? 'error-line' : 'info-line';
      div.textContent = '[' + item.type.toUpperCase() + '] ' + item.message;
      errors.appendChild(div);
    });
  }
  function runPreview() {
    logItems = [];
    renderErrors();
    status.textContent = 'Preview চলছে — সব ধরনের HTML/CSS ভুল স্বয়ংক্রিয়ভাবে শনাক্ত করা সম্ভব নয়।';
    let code = '';
    try { code = localStorage.getItem('aether_code') || '<h1>No code found</h1>'; }
    catch (_) { code = '<h1>Local storage unavailable</h1>'; }
    const bridge = `<script>
      (function(){
        function send(type, args){
          try { parent.postMessage({aetherPreviewLog:true,type:type,message:Array.from(args).map(function(x){try{return typeof x==='string'?x:JSON.stringify(x)}catch(e){return String(x)}}).join(' ')}, '*'); } catch(e){}
        }
        ['log','warn','error','info'].forEach(function(type){
          var old = console[type];
          console[type] = function(){ send(type, arguments); if(old) old.apply(console, arguments); };
        });
        window.addEventListener('error', function(e){ send('error', [e.message + (e.lineno ? ' (line ' + e.lineno + ')' : '')]); });
        window.addEventListener('unhandledrejection', function(e){ send('error', ['Unhandled promise rejection: ' + (e.reason && e.reason.message ? e.reason.message : e.reason)]); });
      })();
    <\/script>`;
    const headIndex = code.toLowerCase().indexOf('<head>');
    if (headIndex >= 0) code = code.slice(0, headIndex + 6) + bridge + code.slice(headIndex + 6);
    else code = bridge + code;
    frame.srcdoc = code;
  }
  window.addEventListener('message', event => {
    if (!event.data || !event.data.aetherPreviewLog) return;
    logItems.push({type:event.data.type, message:event.data.message || '(no message)'});
    renderErrors();
  });
  document.getElementById('backBtn').addEventListener('click', () => { location.href = 'index.html'; });
  document.getElementById('refreshBtn').addEventListener('click', runPreview);
  document.getElementById('clearErrors').addEventListener('click', () => { logItems = []; renderErrors(); });
  runPreview();
})();
